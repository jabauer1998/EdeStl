package ede.stl.values;

import ede.stl.gui.GuiEde;
import ede.stl.values.Value;

public class EdeRegVal implements Value{
    private String regString;
    private GuiEde gui;

    public EdeRegVal(String regValueString, GuiEde edeInstance){
        this.gui = edeInstance;
        this.regString = regValueString;
    }

    public void setAllBits(int value){
        gui.setRegisterValue(regString, value);
    }

    public void setBitAtIndex(int index, int value){
        long regValue = gui.getRegisterValue(regString);
        boolean bitSet = value != 0;
        if(!bitSet){
            regValue &= ~(1L << index);
        } else {
            regValue |= (1L << index);
        }
        gui.setRegisterValue(regString, regValue);
    }

    public long getBitAtIndex(int index){
        long regValue = gui.getRegisterValue(regString);
        return (regValue >> index) & 1;
    }

    public void setBitsAtIndex(int maxIndex, int minIndex, int value){
        long regValue = gui.getRegisterValue(regString);
        if(minIndex < maxIndex){
            int index = minIndex;
            int size = maxIndex - minIndex + 1;
            int numIndex = 0;
            while(index <= maxIndex && numIndex < size){
                boolean isSet = ((value >> numIndex) & 1) != 0;
                if(isSet){
                    regValue |= (1L << index);
                } else {
                    regValue &= ~(1L << index);
                }
                index++;
                numIndex++;
            }
            gui.setRegisterValue(regString, regValue);
        } else {
            int index = minIndex;
            int size = minIndex - maxIndex + 1;
            int numIndex = 0;
            while(index >= maxIndex && numIndex < size){
                boolean isSet = ((value >> numIndex) & 1) != 0;
                if(isSet){
                    regValue |= (1L << index);
                } else {
                    regValue &= ~(1L << index);
                }
                index--;
                numIndex++;
            }
            gui.setRegisterValue(regString, regValue);
        }
    }

    public long getBitsInRange(int begin, int end){
        long val = this.longValue();
        if(begin < end){
            long mask = (1L << (end + 1)) - 1;
            mask ^= (1L << begin) - 1;
            return (val & mask) >> begin;
        } else {
            long mask = (1L << (begin + 1)) - 1;
            mask ^= (1L << end) - 1;
            return (val & mask) >> end;
        }
    }

    @Override
    public double realValue(){
        return (double)gui.getRegisterValue(regString);    
    }

    @Override
    public long longValue(){
        return (long)gui.getRegisterValue(regString);
    }
    @Override
    public int intValue(){
        return (int)gui.getRegisterValue(regString);
    }
    @Override
    public short shortValue(){
        return (short)gui.getRegisterValue(regString);
    }

    @Override
    public byte byteValue(){
        return (byte)gui.getRegisterValue(regString);
    }
    
    @Override
    public boolean boolValue(){
        return gui.getRegisterValue(regString) != 0;
    }

    @Override
    public boolean isBoolValue(){
        return false;
    }
    @Override
    public boolean isShortValue(){
        return false;
    }
    @Override
    public boolean isUnsignedShortValue(){
        return false;
    }
    @Override
    public boolean isByteValue(){
        return false;
    }
    @Override
    public boolean isUnsignedByteValue(){
        return false;
    }
    @Override
    public boolean isIntValue(){
        return false;
    }
    @Override
    public boolean isUnsignedIntValue(){
        return false;
    }
    @Override
    public boolean isLongValue(){
        return false;
    }
    @Override
    public boolean isUnsignedLongValue(){
        return false;
    }
    @Override
    public boolean isRealValue(){
        return false;
    }
    @Override
    public boolean isStringValue(){
        return false;
    }
    @Override
    public boolean isVector(){
        return false;
    }
    @Override
    public boolean isRegister(){
        return false;
    }
    @Override
    public boolean isWire(){ // TODO Auto-generated method stub
        return false;
    }

    @Override
    public Value getShallowSlice(int startIndex, int endIndex) throws Exception{ // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'getShallowSlice'"); }

    
}
